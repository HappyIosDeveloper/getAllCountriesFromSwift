import UIKit


struct CountryCode {
    let country: String?
    let fa: String?
    let code: String
    let flag: String
}

let countries: [CountryCode] = NSLocale.isoCountryCodes.map {
    
        func flag(country:String) -> String {
            let base : UInt32 = 127397
            var s = ""
            for v in country.unicodeScalars {
                s.unicodeScalars.append(UnicodeScalar(base + v.value)!)
            }
            return String(s)
        }
    
    let country = (Locale.current as NSLocale).displayName(forKey: .countryCode, value: $0)
    let id = NSLocale.localeIdentifier(fromComponents: [NSLocale.Key.countryCode.rawValue: $0])
    let fa = NSLocale(localeIdentifier: "fa").displayName(forKey: NSLocale.Key.identifier, value: id)
    return CountryCode(country: country, fa: fa!, code: $0, flag: flag(country: $0))
}

countries.compactMap { print($0) }
